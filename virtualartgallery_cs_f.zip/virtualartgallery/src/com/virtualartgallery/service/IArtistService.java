package com.virtualartgallery.service;


import java.util.List;

import com.virtualartgallery.entity.ArtWork;
import com.virtualartgallery.entity.Artist;

public interface IArtistService {

	public int addArtist(Artist artist) ;
	public int updateArtist(Artist artist) ;
	public int deleteArtist(int artistId) ;
	public List<Artist>viewArtists() ;
	public Artist viewArtist(int artistId);
	
	
	
}
