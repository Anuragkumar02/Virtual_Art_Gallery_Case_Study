package com.virtualartgallery.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.virtualartgallery.dao.ArtistDAOImpl;
import com.virtualartgallery.dao.IArtistDAO;
import com.virtualartgallery.entity.ArtWork;
import com.virtualartgallery.entity.Artist;
import com.virtualartgallery.exception.ArtistNotFoundException;

public class ArtistServiceImpl implements IArtistService {

	IArtistDAO iArtistDAO;
	
	public ArtistServiceImpl() {
		
		iArtistDAO = new ArtistDAOImpl();
		
	}
	
	
	@Override
	public int addArtist(Artist artist) {
		int res = 0;
		
		try {
			res = iArtistDAO.addArtist(artist);
		}catch(SQLException s) {
			System.out.println("Either url,username,password or Query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(IllegalArgumentException iae) {
			System.out.println("Enter Date in mentioned Format only");
		}
		return res;
		
	}

	@Override
	public int updateArtist(Artist artist) {
		int res = 0;
		
		try {
			res = iArtistDAO.updateArtist(artist);
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username,password or query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(IllegalArgumentException iae) {
			System.out.println("Enter Date in mentioned Format only");
		}catch(ArtistNotFoundException anfe){
			System.out.println("Artist Not Found ");
		}
		return res;
	}

	@Override
	public int deleteArtist(int artistId) {
		int res = 0;
		
		try {
			res = iArtistDAO.deleteArtist(artistId);
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username,password or query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(ArtistNotFoundException anfe){
			System.out.println("Artist Not Found ");
		}
		return res;
	}

	@Override
	public List<Artist> viewArtists() {
		List<Artist> artistList = new ArrayList<>();
		
		try {
			artistList = iArtistDAO.viewArtists();
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username,password or query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(ArtistNotFoundException anfe){
			System.out.println("Not Artists Found ");
		}
		return artistList;
	}

	@Override
	public Artist viewArtist(int artistId) {
		Artist artist = null;
		
		try {
			artist = iArtistDAO.viewArtist(artistId);
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username,password or query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(ArtistNotFoundException anfe){
			System.out.println("Artist Not Found ");
		}
		return artist;
	}
	

}
