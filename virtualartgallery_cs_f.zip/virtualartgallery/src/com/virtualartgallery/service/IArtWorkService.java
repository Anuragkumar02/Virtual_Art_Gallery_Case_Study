package com.virtualartgallery.service;

import java.util.List;

import com.virtualartgallery.entity.ArtWork;

public interface IArtWorkService {
	
	
	public int addArtWork(ArtWork artwork);
	public int updateArtWork(ArtWork artwork)  ;
	public int removeArtWork(int artWorkid)  ;
	public ArtWork getArtWorkById(int artWorkId) ;
	public List<ArtWork> searchArtworks(String keyword) ;
	public List<ArtWork> viewArtworks();
	
	
	
}
