package com.virtualartgallery.dao;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.virtualartgallery.entity.ArtWork;
import com.virtualartgallery.exception.ArtWorkNotFoundException;
import com.virtualartgallery.util.DBConnection;

class ArtWorkDAOImplTest {
	
	private static Connection connection;
	private IArtWorkDAO iArtWorkDAO;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		connection = DBConnection.getConnection();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		connection = null;
	}

	@BeforeEach
	void setUp() throws Exception {
		
		iArtWorkDAO = new ArtWorkDAOImpl();
		
	}

	@AfterEach
	void tearDown() throws Exception {
		iArtWorkDAO = null;
	}

	@Test
	void testAddArtWork() {
		int result = 0;
		
		ArtWork artwork = new ArtWork("junittes","mytesting","2023-12-23","oil painting","junit.jpeg");
		
		try {
			result = iArtWorkDAO.addArtWork(artwork);
		}catch(SQLException s) {
			System.out.println("Either url,username,password or Query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(IllegalArgumentException iae) {
			System.out.println("Enter Date in mentioned Format only");
		}
		assertTrue(result == 1);
	}

	@Test
	void testUpdateArtWork() {
		int res = 0;
		ArtWork artwork = new ArtWork(19,"junittes","updatetest","2023-12-23","oil painting","junit.jpeg");
		try {
			res = iArtWorkDAO.updateArtWork(artwork);
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username,password or Query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(IllegalArgumentException iae) {
			System.out.println("Enter Date in mentioned Format only");
		}catch(ArtWorkNotFoundException awn) {
			System.out.println("ArtWork Not Found");
		}
		assertTrue(res == 1);
	}

	@Test
	void testRemoveArtWork() {
		int res = 0;
		int artWorkId = 17;
		try {
			res = iArtWorkDAO.removeArtWork(artWorkId);
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username,password or Query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(ArtWorkNotFoundException awn) {
			System.out.println("ArtWork Not Found");
		}
		assertTrue(res == 1);
	}

	@Test
	void testGetArtWorkById() {
		ArtWork artwork = null;
		int artWorkId = 19;
		try {
			artwork = iArtWorkDAO.getArtWorkById(artWorkId);
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username,password or Query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(ArtWorkNotFoundException awn) {
			System.out.println("ArtWork Not Found");
		}
		
		assertTrue(artwork!=null);
	}

	@Test
	void testSearchArtworks() {
		List<ArtWork> artworks = null;
		
		String keyword = "oil";
		
		try {
			artworks = iArtWorkDAO.searchArtworks(keyword);
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username,password or Query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(ArtWorkNotFoundException awn) {
			System.out.println("ArtWork Not Found");
		}
		assertTrue(artworks!=null);
	}

	@Test
	void testViewArtworks() {
		List<ArtWork> artworks = null;
		
		try {
			artworks = iArtWorkDAO.viewArtworks();
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username,password or query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(ArtWorkNotFoundException anfe){
			System.out.println("Artist Not Found ");
		}
		
		assertTrue(artworks!=null);
	}

}
