package com.virtualartgallery.dao;

import java.sql.SQLException;
import java.util.List;

import com.virtualartgallery.entity.Artist;
import com.virtualartgallery.exception.ArtistNotFoundException;

public interface IArtistDAO {
	
	
	public int addArtist(Artist artist) throws SQLException,ClassNotFoundException,IllegalArgumentException;
	public int updateArtist(Artist artist) throws ArtistNotFoundException,SQLException,ClassNotFoundException,IllegalArgumentException;
	public int deleteArtist(int artistId) throws ArtistNotFoundException,SQLException,ClassNotFoundException;
	public List<Artist>viewArtists() throws ArtistNotFoundException,SQLException,ClassNotFoundException;
	public Artist viewArtist(int artistId) throws ArtistNotFoundException,SQLException,ClassNotFoundException;

}
