package com.virtualartgallery.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.virtualartgallery.entity.Artist;
import com.virtualartgallery.entity.Gallery;
import com.virtualartgallery.exception.GalleryNotFoundException;
import com.virtualartgallery.util.DBConnection;

public class GalleryDAOImpl implements IGalleryDAO {
	
	private static Connection connection;

	@Override
	public int addGallery(Gallery gallery) throws SQLException, ClassNotFoundException {
		connection = DBConnection.getConnection();
		
		String query = "INSERT INTO gallery(name,description,location,curator,openinghours) VALUES(?,?,?,?,?)";
		
		PreparedStatement prepareStgallery = connection.prepareStatement(query);
		
		prepareStgallery.setString(1,gallery.getName());
		prepareStgallery.setString(2,gallery.getDescription());
		prepareStgallery.setString(3,gallery.getLocation());
		prepareStgallery.setInt(4,gallery.getArtist().getArtistId());
		prepareStgallery.setString(5,gallery.getOpeningHour());
		int result = prepareStgallery.executeUpdate();
		DBConnection.closeConnection();
		return result;
	}

	@Override
	public int updateGallery(Gallery gallery) throws GalleryNotFoundException, SQLException, ClassNotFoundException {
		connection = DBConnection.getConnection();
		
		
		
		String query = "UPDATE gallery SET name = ?,description = ?, location = ?,curator = ?,openinghours = ?"+"WHERE galleryid = ?";
		
		PreparedStatement stmtUpd = connection.prepareStatement(query);
		
		stmtUpd.setString(1, gallery.getName());
		stmtUpd.setString(2,gallery.getDescription());
		stmtUpd.setString(3,gallery.getLocation());
		
		stmtUpd.setInt(4,gallery.getArtist().getArtistId());
		stmtUpd.setString(5,gallery.getOpeningHour());
		stmtUpd.setInt(6, gallery.getGalleryId());
		
		int result = stmtUpd.executeUpdate();
		
		
		if (result == 0) {
			throw new GalleryNotFoundException("Gallery Not Found ");
		}

		connection.close();
		
		return result ;
		
	}

	@Override
	public int deleteGallery(int galleryId) throws GalleryNotFoundException, SQLException, ClassNotFoundException {
		connection = DBConnection.getConnection();
		
		String query = "DELETE FROM gallery WHERE galleryid = ?";
		
		PreparedStatement stmtDel =connection.prepareStatement(query);
		
		stmtDel.setInt(1, galleryId);
		
		int result = stmtDel.executeUpdate();
		
		
		if(result == 0) {
			throw new GalleryNotFoundException("Gallery Not Found ");
		}
		
		connection.close();
		
		return result;
		
		
	}

	@Override
	public Gallery viewGallery(int galleryId) throws GalleryNotFoundException, SQLException, ClassNotFoundException {
		connection = DBConnection.getConnection();
		
		Gallery gallery = null;
		
		int artistId = 0;
		String aname = null;
		String biography = null;
		Date birthDate =  null;
		String nationality = null;
		String website = null;
		String contactInformation = null;
		
		String gname = null;
		String description = null;
		String location =  null;
		String openingHour = null;
		
		
		String queryFind ="SELECT g.name 'gname',a.name 'aname',a.*,g.* FROM gallery g "
				        + "JOIN artist a "
				        + "ON g.curator = a.artistid "
				        + "WHERE galleryId = ?";
		
		PreparedStatement pstmt = connection.prepareStatement(queryFind);
		
		pstmt.setInt(1, galleryId);
		
	    ResultSet rsGallery = pstmt.executeQuery();
	    
	    while(rsGallery.next()) {
	    		
	    		artistId = rsGallery.getInt("curator");
				aname = rsGallery.getString("aname");
				biography = rsGallery.getString("biography");
				birthDate = rsGallery.getDate("birthdate");
				
				DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			    String strbirthDate = dateFormat.format(birthDate);
				
				nationality=rsGallery.getString("nationality");
				website=rsGallery.getString("website");
				contactInformation=rsGallery.getString("contactInformation");
	    		
	    		gname  = rsGallery.getString("gname");
	    		description = rsGallery.getString("description");
	    		location = rsGallery.getString("location");
	    		openingHour = rsGallery.getString("openingHours");
	    		
	    		Artist artist = new Artist(artistId,aname,biography,strbirthDate,nationality,website,contactInformation);
	    				
	    		
	    		gallery =  new Gallery(galleryId,gname,location,openingHour,description,artist);
	    		
	    	}
	    if(gallery == null) {
	    	throw new GalleryNotFoundException("Gallery not Found ");
	    }
	   
	    
		return gallery;
	}

	@Override
	public List<Gallery> viewGallerys() throws GalleryNotFoundException, SQLException, ClassNotFoundException {
		
		connection = DBConnection.getConnection();
		
		int artistId = 0;
		String aname = null;
		String biography = null;
		Date birthDate =  null;
		String nationality = null;
		String website = null;
		String contactInformation = null;
		
		int galleryId = 0;
		String gname = null;
		String description = null;
		String location =  null;
		String openingHour = null;
		
		List<Gallery> galleryList = new ArrayList<>();
		
		String allGallerysQuery ="SELECT g.name 'gname',a.name 'aname',a.*,g.* FROM gallery g "
		                       + "JOIN artist a "
		                       + "ON g.curator = a.artistid ";
		PreparedStatement pstmt = connection.prepareStatement(allGallerysQuery);
		
		ResultSet rs = pstmt.executeQuery();
		
		while(rs.next()) {
			
			artistId = rs.getInt("curator");
			aname = rs.getString("aname");
			biography = rs.getString("biography");
			birthDate = rs.getDate("birthdate");
			
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		    String strbirthDate = dateFormat.format(birthDate);
			
			nationality=rs.getString("nationality");
			website=rs.getString("website");
			contactInformation=rs.getString("contactInformation");
			
			galleryId = rs.getInt("galleryId");
			gname  = rs.getString("gname");
    		description = rs.getString("description");
    		location = rs.getString("location");
    		openingHour = rs.getString("openingHours");
    		
    		
    		
    		Artist artist = new Artist(artistId,aname,biography,strbirthDate,nationality,website,contactInformation);
    		
    		Gallery gallery =  new Gallery(galleryId,gname,location,openingHour,description,artist);
    		
    		gallery.setArtist(artist);
    		
    		galleryList.add(gallery);
			
		}
		
		if(galleryList.size()== 0) {
			throw new GalleryNotFoundException("No Galleries Found");
		}
		
		return galleryList;
	}

}
