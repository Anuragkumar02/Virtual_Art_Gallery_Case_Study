package com.virtualartgallery.dao;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.virtualartgallery.entity.Artist;
import com.virtualartgallery.exception.ArtistNotFoundException;
import com.virtualartgallery.util.DBConnection;

class ArtistDAOImplTest {
	
	private static Connection connection;
	private static IArtistDAO iArtistDAO;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		iArtistDAO = new ArtistDAOImpl();
		
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		iArtistDAO = null;
	}

	@BeforeEach
	void setUp() throws Exception {
		connection = DBConnection.getConnection();
	}

	@AfterEach
	void tearDown() throws Exception {
		connection = null;
	}

	@Test
	void testAddArtist() {
		int res = 0;
		Artist artist = new Artist("Mahesh","Best artist in Hand arts","1987-12-25","Indian","www.mahiarts.com","0503081888");
		
		try {
			res = iArtistDAO.addArtist(artist);
		}catch(SQLException s) {
			System.out.println("Either url,username,password or Query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(IllegalArgumentException iae) {
			System.out.println("Enter Date in mentioned Format only");
		}
		assertTrue(res==1);
	}

	@Test
	void testUpdateArtist() {
		int res = 0;
		Artist artist = new Artist(17,"Mahesh","Best artist in Hand arts","1988-12-25","Indian","www.mahiarts.com","0503081888");
		try {
			res = iArtistDAO.updateArtist(artist);
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username,password or query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(IllegalArgumentException iae) {
			System.out.println("Enter Date in mentioned Format only");
		}catch(ArtistNotFoundException anfe){
			System.out.println("Artist Not Found ");
		}
		assertTrue(res==1);
	}

	@Test
	void testDeleteArtist() {
		int res = 0;
		int artistId = 17;
		try {
			res = iArtistDAO.deleteArtist(artistId);
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username,password or query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(ArtistNotFoundException anfe){
			System.out.println("Artist Not Found ");
		}
		assertTrue(res==1);
	}

	@Test
	void testViewArtists() {
		List<Artist> artistList = new ArrayList<>();
		
		try {
			artistList = iArtistDAO.viewArtists();
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username,password or query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(ArtistNotFoundException anfe){
			System.out.println("Not Artists Found ");
		}
		assertTrue(artistList.size()!=0);
	}

	@Test
	void testViewArtist() {
		Artist artist = null;
		int artistId = 9;
		try {
			artist = iArtistDAO.viewArtist(artistId);
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username,password or query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(ArtistNotFoundException anfe){
			System.out.println("Artist Not Found ");
		}
		assertTrue(artist!=null);
	}

}
