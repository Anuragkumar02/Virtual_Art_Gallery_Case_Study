package com.virtualartgallery.dao;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.virtualartgallery.entity.ArtWork;
import com.virtualartgallery.entity.User;
import com.virtualartgallery.exception.ArtWorkNotFoundException;
import com.virtualartgallery.exception.FavArtWorkNotFoundException;
import com.virtualartgallery.exception.UserNotFoundException;
import com.virtualartgallery.util.DBConnection;

class UserDAOImplTest {
	
	private static Connection connection;
	private static IUserDAO iUserDAO;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		iUserDAO = new UserDAOImpl();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		iUserDAO = null;
	}

	@BeforeEach
	void setUp() throws Exception {
		connection = DBConnection.getConnection();
	}

	@AfterEach
	void tearDown() throws Exception {
		connection.close();
		
	}

	@Test
	void testAddUser() {
		int result = 0;
		try {
			User user = new User("mahesh123","Mahesh123","mahesh@gmail.com","Prince","Mahesh","2020-12-24","/Users/teja/Desktop/Java FTP/Myimage.jpeg");
			result = iUserDAO.addUser(user);
		}catch(ClassNotFoundException cfne) {
			System.out.println("Looks like JDBC driver is not loaded");
		}catch(SQLException s) {
			System.out.println("Either url,username or password is wrong or duplicate record");
		} catch (IllegalArgumentException e) {
			System.out.println("Enter Date in mentioned format only");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		assertTrue(result==1);
	}

	@Test
	void testUpdateUser() {
		int result =0;
		User user = new User(1009,"Teja123","123","tejsai@gmail.com","Prince","Mahesh","2020-12-24",null);
		try {
			result = iUserDAO.updateUser(user);
		}catch(ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC  is not loaded");
		}catch(SQLException s) {
			System.out.println("Either url,username or password");
		}catch(UserNotFoundException u) {
			System.out.println(u.getMessage());
		}catch(IllegalArgumentException iae) {
			System.out.println("Incorrect Date Format");
		}
		assertTrue(result==1);
	}

	@Test
	void testDeleteUser() {
		int result =0;
		int userId = 1013;
		try {
			result = iUserDAO.deleteUser(userId);
		}catch(ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC  is not loaded");
		}catch(SQLException s) {
			System.out.println("Either url,username or password");
			
		}catch(UserNotFoundException u) {
			System.out.println(u.getMessage());
		}
		
		assertTrue(result==1);
	}

	@Test
	void testViewUser() {
		User user = null;
		int userId = 1009;
		try {
			user = iUserDAO.viewUser(userId);
		}catch(ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC  is not loaded");
		}catch(SQLException s) {
			System.out.println("Either url,username or password");
			
		}catch(UserNotFoundException u) {
			System.out.println(u.getMessage());
		}catch(FileNotFoundException fnfe) {
			System.out.println("File Not Found");
		}catch(IOException ioe) {
			System.out.println("Enter Correct path");
		}
		assertTrue(user!=null);
	}

	@Test
	void testViewUsers() {
		List<User>userList = null;
		
		try {
			userList = iUserDAO.viewUsers();
		}catch(ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC  is not loaded");
		}catch(SQLException s) {
			System.out.println("Either url,username or password");
			
		}catch(UserNotFoundException u) {
			System.out.println(u.getMessage());
		}
		
		assertTrue(userList.size()!=0);
	}

	@Test
	void testAddArtworkToFavorite() {
		int result = 0;
		try {
			result = iUserDAO.addArtworkToFavorite(1009,2);
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username,password or Query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(ArtWorkNotFoundException awn) {
			System.out.println("ArtWork Not Found");
		}catch(UserNotFoundException unfe) {
			System.out.println("User Not Found");
		}
		assertTrue(result!=0);
	}

	@Test
	void testRemoveArtworkFromFavorite() {
		int res = 0;
		try {
			res = iUserDAO.removeArtworkFromFavorite(1009,2);
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username,password or Query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(ArtWorkNotFoundException awn) {
			System.out.println(awn.getMessage());
		}catch(UserNotFoundException unfe) {
			System.out.println(unfe.getMessage());
		}catch(FavArtWorkNotFoundException fwne) {
			System.out.println(fwne.getMessage());
		}
		assertTrue(res!=0);
	}

	@Test
	void testGetUserFavoriteArtworks() {
		List<ArtWork> artworks= null;
		
		int userId = 1004;
		
		try {
			artworks = iUserDAO.getUserFavoriteArtworks(userId);
		}catch(SQLException s) {
			s.printStackTrace();
			System.out.println("Either url,username,password or Query are wrong");
		}catch(ClassNotFoundException cnfe) {
			System.out.println("JDBC not connected to DataBase");
		}catch(FavArtWorkNotFoundException fawn) {
			System.out.println(fawn.getMessage());
		}catch(UserNotFoundException unfe) {
			System.out.println(unfe.getMessage());
		}
		assertTrue(artworks!=null);
	}

}
