package com.virtualartgallery.dao;

import java.sql.SQLException;
import java.util.List;

import com.virtualartgallery.entity.Gallery;
import com.virtualartgallery.exception.GalleryNotFoundException;

public interface IGalleryDAO {
	
	public int addGallery(Gallery gallery) throws SQLException,ClassNotFoundException;
	public int updateGallery(Gallery gallery) throws GalleryNotFoundException,SQLException,ClassNotFoundException;
	public int deleteGallery(int galleryId) throws GalleryNotFoundException,SQLException,ClassNotFoundException;
	public Gallery viewGallery(int galleryId) throws GalleryNotFoundException,SQLException,ClassNotFoundException;
	public List<Gallery>viewGallerys() throws GalleryNotFoundException,SQLException,ClassNotFoundException;

}
