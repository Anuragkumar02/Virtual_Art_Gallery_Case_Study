package com.virtualartgallery.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.virtualartgallery.entity.Artist;
import com.virtualartgallery.exception.ArtistNotFoundException;
import com.virtualartgallery.util.DBConnection;

public class ArtistDAOImpl implements IArtistDAO {

	private static Connection connection;
	@Override
	public int addArtist(Artist artist) throws SQLException, ClassNotFoundException,IllegalArgumentException {
		connection = DBConnection.getConnection();
        int count = 0;

        String queryAdd = "INSERT INTO Artist VALUES (?, ?, ?, ?, ?, ?, ?)";

        PreparedStatement pstn = connection.prepareStatement(queryAdd) ;
        pstn.setInt(1, artist.getArtistId());
        pstn.setString(2, artist.getName());
        pstn.setString(3, artist.getBiography());
        
        String  dob =  artist.getBirthDate();
        Date sqlDate =Date.valueOf(dob);
		pstn.setDate(4, sqlDate);
        pstn.setString(5, artist.getNationality());
        pstn.setString(6, artist.getWebsite());
        pstn.setString(7, artist.getContactInformation());


        count = pstn.executeUpdate();
        
        
        return count;
	}

	@Override
	public int updateArtist(Artist artist) throws ArtistNotFoundException, SQLException, ClassNotFoundException ,IllegalArgumentException{
		
		connection = DBConnection.getConnection();
        int count = 0;

        String queryUpdate = "UPDATE Artist SET name =?,biography=?,birthdate=?,nationality=?,website=?,contactinformation=? "
        		           + "WHERE artistid=?";

        PreparedStatement pstn = connection.prepareStatement(queryUpdate) ;
        
        pstn.setString(1, artist.getName());
        pstn.setString(2, artist.getBiography());
        
        String  dob =  artist.getBirthDate();
        Date sqlDate =Date.valueOf(dob);
		pstn.setDate(3, sqlDate);
        pstn.setString(4, artist.getNationality());
        pstn.setString(5, artist.getWebsite());
        pstn.setString(6, artist.getContactInformation());

        pstn.setInt(7, artist.getArtistId());
        count = pstn.executeUpdate();
        
        if(count==0) {
        	throw new ArtistNotFoundException("Artist Not Found");
        }
        
        
        return count;
	}

	@Override
	public int deleteArtist(int artistId) throws ArtistNotFoundException, SQLException, ClassNotFoundException {
		
		    connection = DBConnection.getConnection();

		    String removeArtistQuery = "DELETE FROM Artist WHERE ArtistID=?";

		   PreparedStatement pstn = connection.prepareStatement(removeArtistQuery);
		   
		   int check = 0;
		   pstn.setInt(1, artistId);
		   check = pstn.executeUpdate();

		   if (check == 0) {
		      throw new ArtistNotFoundException("Artist Not Found");
		   }

		    connection.close();

		    return check;
	}

	@Override
	public List<Artist> viewArtists() throws ArtistNotFoundException, SQLException, ClassNotFoundException {
		
		connection = DBConnection.getConnection();
		
		ArrayList<Artist> artistList = new ArrayList<>();
		
		int artistId = 0;
		String name = null;
		String biography = null;
		String birthDate = null;
		String nationality =null;
		String website = null;
		String contactInformation =null;
		
		
		String query = "SELECT * FROM artist";
		
		PreparedStatement stmt = connection.prepareStatement(query);
		
		ResultSet rs = stmt.executeQuery();
		
		while(rs.next()) {
			
			artistId = rs.getInt("artistId");
			name =  rs.getString("name");
			biography = rs.getString("biography");
			Date date = rs.getDate("birthdate");
			
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			birthDate = dateFormat.format(date);
			
			nationality = rs.getString("nationality");
			website = rs.getString("website");
			contactInformation = rs.getString("contactInformation");
			
			Artist artist = new Artist(artistId,name,biography,birthDate,nationality,website,contactInformation);
			
			artistList.add(artist);
			
			
		}
		
		if(artistList.size()==0) {
			throw new ArtistNotFoundException("No artists Found");
		}
		
		return artistList;
		
	}

	@Override
	public Artist viewArtist(int artistId) throws ArtistNotFoundException, SQLException, ClassNotFoundException {
connection = DBConnection.getConnection();
		
		Artist artist = null;

		String name = null;
		String biography = null;
		String birthDate = null;
		String nationality =null;
		String website = null;
		String contactInformation =null;
		
		
		String query = "SELECT * FROM artist WHERE artistid = ?";
		
		PreparedStatement stmt = connection.prepareStatement(query);
		
		stmt.setInt(1, artistId);
		
		ResultSet rs = stmt.executeQuery();
		
		while(rs.next()) {
			
			artistId = rs.getInt("artistId");
			name =  rs.getString("name");
			biography = rs.getString("biography");
			Date date = rs.getDate("birthdate");
			
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			birthDate = dateFormat.format(date);
			
			nationality = rs.getString("nationality");
			website = rs.getString("website");
			contactInformation = rs.getString("contactInformation");
			
			artist = new Artist(artistId,name,biography,birthDate,nationality,website,contactInformation);
			
			
			
		}
		
		if(artist == null) {
			throw new ArtistNotFoundException("Artist Not Found");
		}
		
		return artist;
		

}
}
