package com.virtualartgallery.dao;


import java.awt.Image;
import java.awt.Toolkit;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import com.virtualartgallery.entity.ArtWork;
import com.virtualartgallery.entity.User;
import com.virtualartgallery.exception.ArtWorkNotFoundException;
import com.virtualartgallery.exception.FavArtWorkNotFoundException;
import com.virtualartgallery.exception.UserNotFoundException;
import com.virtualartgallery.util.DBConnection;

public class UserDAOImpl implements IUserDAO {
	
	private static Connection connection;
	
	@Override
	public int addUser(User user) throws ClassNotFoundException,SQLException,IllegalArgumentException,IOException{
		connection = DBConnection.getConnection();
		
		String query = "INSERT INTO User(username,password,email,firstname,lastname,dateofbirth,profilepicture) VALUES(?,?,?,?,?,?,?)";
		
		PreparedStatement prepareStUser = connection.prepareStatement(query);
		
		prepareStUser.setString(1,user.getUserName());
		prepareStUser.setString(2,user.getPassWord());
		prepareStUser.setString(3,user.getEmail());
		prepareStUser.setString(4,user.getFirstName());
		prepareStUser.setString(5,user.getLastName());
		
		String dob = user.getDateOfBirth();
		Date sqlDate =Date.valueOf(dob);
		
		prepareStUser.setDate(6,sqlDate);
		
		
		String imagePath = user.getProfilePicture();
		
		 File imageFile = new File(imagePath);
         FileInputStream fis = new FileInputStream(imageFile);
         byte[] imageData = new byte[(int) imageFile.length()];
         fis.read(imageData);
         fis.close();
		
         prepareStUser.setBytes(7, imageData);
         ///Users/teja/Desktop/Java FTP/Myimage.jpeg
		int result = prepareStUser.executeUpdate();
		DBConnection.closeConnection();
		return result;
	}
	
	
	@Override
	public int updateUser(User user) throws UserNotFoundException ,ClassNotFoundException,SQLException{
		connection = DBConnection.getConnection();
		
		String query = "Update User SET username=?,password=?,email=?,firstname=?,lastname=?,dateofbirth=? WHERE userid=?";
		
		PreparedStatement prepareStUser = connection.prepareStatement(query);
		
		prepareStUser.setString(1,user.getUserName());
		prepareStUser.setString(2,user.getPassWord());
		prepareStUser.setString(3,user.getEmail());
		prepareStUser.setString(4,user.getFirstName());
		prepareStUser.setString(5,user.getLastName());
		
		String dob = user.getDateOfBirth();
		Date sqlDate =Date.valueOf(dob);
		
		prepareStUser.setDate(6,sqlDate);
		prepareStUser.setInt(7, user.getUserId());
         ///Users/teja/Desktop/Java FTP/Myimage.jpeg
		int result = prepareStUser.executeUpdate();
		if(result==0) {
			throw new UserNotFoundException("User Not Found");
		}
		
		DBConnection.closeConnection();
		return result;
		
	}

	@Override
	public int deleteUser(int userId) throws UserNotFoundException,ClassNotFoundException,SQLException {
		User user = null;
		
		String userName = null;
		String password = null;
		String email = null;
		String firstname = null;
		String lastname = null;
		String dateofbirth = null;
		
		int result =0;
		
		
		connection = DBConnection.getConnection();
		
		String queryCheck = "SELECT * FROM user WHERE userId=?";
		String queryDelete = "DELETE FROM user WHERE userid=?";
		
		
		PreparedStatement prepareStUser = connection.prepareStatement(queryCheck);
		
		PreparedStatement prepareUserDel = connection.prepareStatement(queryDelete);
		
		prepareStUser.setInt(1,userId);
		prepareUserDel.setInt(1,userId);
		
		ResultSet rsUser = prepareStUser.executeQuery(); 
		
		while(rsUser.next()) {
			userId = rsUser.getInt("userId");
		    userName = rsUser.getString("userName");
			password = rsUser.getString("password");
			email = rsUser.getString("email");
			firstname = rsUser.getString("firstname");
			lastname = rsUser.getString("lastname");
			dateofbirth = rsUser.getString("dateofbirth");
			
		    user = new User(userName,password,email,firstname,lastname,dateofbirth,null);
		    user.setUserId(userId);
		    
		}
		
		
		if(user == null) {
			throw new UserNotFoundException("No User Found");
		}else {
			result = prepareUserDel.executeUpdate();
		}
		
		DBConnection.closeConnection();
		return result;

	}

	@Override
	public User viewUser(int userId) throws UserNotFoundException ,ClassNotFoundException,SQLException, IOException{
		// TODO Auto-generated method stub
        
		User user = null;
		String userName = null;
		String password = null;
		String email = null;
		String firstname = null;
		String lastname = null;
		String dateofbirth = null;
				
		connection = DBConnection.getConnection();
		
		String query = "SELECT * FROM user WHERE userId=?";
		
		
		PreparedStatement prepareStUser = connection.prepareStatement(query);
		
		prepareStUser.setInt(1,userId);
		
		ResultSet rsUser = prepareStUser.executeQuery(); 
		
		while(rsUser.next()) {
			userId = rsUser.getInt("userId");
		    userName = rsUser.getString("userName");
			password = rsUser.getString("password");
			email = rsUser.getString("email");
			firstname = rsUser.getString("firstname");
			lastname = rsUser.getString("lastname");
			dateofbirth = rsUser.getString("dateofbirth");
			byte[] profilePicture = rsUser.getBytes("profilepicture");
			
			String outputFile = "/Users/teja/Desktop/Java FTP/Myimage"+userId+".jpeg";
			
			OutputStream outputStream = new FileOutputStream(outputFile) ;
            outputStream.write(profilePicture);
            System.out.println("BLOB data retrieved and saved to " + outputFile);
            
            // Convert the byte array to an Image and display it using Swing
            Image image = Toolkit.getDefaultToolkit().createImage(profilePicture);
            
            // Create a JLabel to display the Image
            JLabel label = new JLabel(new ImageIcon(image));
            
            // Create a JFrame to show the JLabel
            JFrame frame = new JFrame("Display Image from BLOB");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.getContentPane().add(label);
            frame.pack();
            frame.setVisible(true);
			
		    user = new User(userName,password,email,firstname,lastname,dateofbirth,null);
		    user.setUserId(userId);
		    
			
		}
		
		DBConnection.closeConnection();
		
		if(user == null) {
			throw new UserNotFoundException("No User Found");
		}
		
		return user;
	}

	@Override
	public List<User> viewUsers() throws UserNotFoundException,SQLException,ClassNotFoundException{
		List<User>users = new ArrayList<>();
		
		connection = DBConnection.getConnection();
		
		String query = "SELECT * FROM user";
		User user = null;
		int userId =0;
		String userName = null;
		String password = null;
		String email = null;
		String firstname = null;
		String lastname = null;
		String dateofbirth = null;
		
		PreparedStatement prepareStUser = connection.prepareStatement(query);
		
		ResultSet rsUser = prepareStUser.executeQuery(); 
		
		while(rsUser.next()) {
			userId = rsUser.getInt("userId");
		    userName = rsUser.getString("userName");
			password = rsUser.getString("password");
			email = rsUser.getString("email");
			firstname = rsUser.getString("firstname");
			lastname = rsUser.getString("lastname");
			dateofbirth = rsUser.getString("dateofbirth");
			
		    user = new User(userName,password,email,firstname,lastname,dateofbirth,null);
		    user.setUserId(userId);
		    
		    users.add(user);
			
		}
		
		DBConnection.closeConnection();
		
		if(users.size() == 0) {
			throw new UserNotFoundException("No User Found");
		}
		
		return users;
	}


	@Override
	public int addArtworkToFavorite(int userId, int artWorkId)
			throws ArtWorkNotFoundException, SQLException, ClassNotFoundException, UserNotFoundException {
		
		connection = DBConnection.getConnection();
		
		int result = 0;
		
		String findArtworkQuery = "SELECT * FROM Artwork WHERE artworkid=?";
		
		String findUserQuery = "SELECT * FROM User WHERE userid = ? ";
		
		String addArtworkToFavoriteQuery = "INSERT INTO UserFavoriteArtworks (userId, artworkId) VALUES (?, ?)";
        
        PreparedStatement addSt = connection.prepareStatement(addArtworkToFavoriteQuery);
        PreparedStatement stFindArt = connection.prepareStatement(findArtworkQuery);
        PreparedStatement stFindUser = connection.prepareStatement(findUserQuery);
        
        stFindArt.setInt(1, artWorkId);
        stFindUser.setInt(1, userId);
        
        addSt.setInt(1, userId);
        addSt.setInt(2, artWorkId);
        
        ResultSet rsUser = stFindUser.executeQuery();
        
        
        ResultSet rsArtwork = stFindArt.executeQuery();
        
        
        if(rsUser.next()== false) {
        	
        	throw new UserNotFoundException("User Not Found");
        }else if(rsArtwork.next()==false) {
        	throw new ArtWorkNotFoundException("ArtWork Not Found");
        }else {
        	result  = addSt.executeUpdate();
        }
        
        
        connection.close();
      
		return result;

		
	}


	@Override
	public int removeArtworkFromFavorite(int userId, int artWorkId)
			throws ArtWorkNotFoundException, SQLException, ClassNotFoundException, UserNotFoundException,FavArtWorkNotFoundException {
		
		connection = DBConnection.getConnection();
		
		int result = 0;
		
		
		String findArtworkQuery = "SELECT * FROM Artwork WHERE artworkid=?";
		
		String findUserQuery = "SELECT * FROM User WHERE userid = ? ";
		
		String findArtFav = "SELECT * FROM UserFavoriteArtWorks WHERE userid = ? and artworkid = ?";
		
		String removeArtworkFromFavoriteQuery = "DELETE FROM UserFavoriteArtWorks WHERE userid = ? and artworkid = ?";
        
	    PreparedStatement findFavArtSt = connection.prepareStatement(findArtFav);
	    PreparedStatement stFindArt = connection.prepareStatement(findArtworkQuery);
	    PreparedStatement stFindUser = connection.prepareStatement(findUserQuery);
        PreparedStatement removeSt = connection.prepareStatement(removeArtworkFromFavoriteQuery);
       
       
        stFindArt.setInt(1, artWorkId);
        stFindUser.setInt(1, userId);
        findFavArtSt.setInt(1, userId);
        findFavArtSt.setInt(2, artWorkId);
        removeSt.setInt(1, userId);
        removeSt.setInt(2, artWorkId);
        
        
        ResultSet rsUser = stFindUser.executeQuery();
        ResultSet rsArtwork = stFindArt.executeQuery();
        ResultSet rsFavArt = findFavArtSt.executeQuery();
        
        if(rsUser.next()== false) {
        	throw new UserNotFoundException("User Not Found Enter Correct UserID");
        }else if (rsArtwork.next() == false) {
        	throw new ArtWorkNotFoundException("ArtWork Not Found Enter Correct ArtWorkId");
        } else if(rsFavArt.next()== false) {
        	throw new FavArtWorkNotFoundException("ArtWork Not Found in User Favorites");
        }else {
        	result = removeSt.executeUpdate();
        }
        connection.close();
      
		return result;
	}

	

	@Override
	public List<ArtWork> getUserFavoriteArtworks(int userId)
			throws UserNotFoundException, FavArtWorkNotFoundException, SQLException, ClassNotFoundException {
		   List<ArtWork> favoriteArtworks = new ArrayList<>();
		   connection = DBConnection.getConnection();
		   
		   String findUserQuery = "SELECT * FROM user WHERE userid = ?";
		   
		   String getUserFavoriteArtworksQuery = "SELECT A.* FROM Artwork A " +
		                                              "JOIN UserFavoriteArtworks F ON A.ArtworkID = F.ArtworkID " +
		                                              "WHERE F.UserID = ?";
		   
		   PreparedStatement pstn = connection.prepareStatement(getUserFavoriteArtworksQuery);
		   PreparedStatement findPstn = connection.prepareStatement(findUserQuery);
		   
		   pstn.setInt(1, userId);
		   findPstn.setInt(1, userId);
		   

		   ResultSet resultSet = pstn.executeQuery();
		   ResultSet rsfind = findPstn.executeQuery();
		   
		   
		   if (rsfind.next()==false) {
			   throw new UserNotFoundException("User Not Found Enter Correct UserID !");
		   }else {
		   while (resultSet.next()) {
		        ArtWork artwork = new ArtWork();
		        artwork.setArtworkId(resultSet.getInt("ArtworkID"));
		        artwork.setTitle(resultSet.getString("Title"));
		        artwork.setDesc(resultSet.getString("Description"));
		        
		        Date creationDate = resultSet.getDate("CreationDate");
		        
		        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			    String strCreationDate = dateFormat.format(creationDate);
		        
		        artwork.setCreationDate(strCreationDate);
		        artwork.setMedium(resultSet.getString("Medium"));
		        artwork.setImageURL(resultSet.getString("ImageURL"));
		        
		        favoriteArtworks.add(artwork);
		  }
		  }
		  
		   
		   if(favoriteArtworks.size()==0  ){
			   throw new FavArtWorkNotFoundException("User doesnot have Favorite Artworks");
		   }
		 
		   
		    return favoriteArtworks;
		}


	
}
