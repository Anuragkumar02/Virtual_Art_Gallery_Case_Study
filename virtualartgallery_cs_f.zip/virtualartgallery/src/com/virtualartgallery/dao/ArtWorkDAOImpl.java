package com.virtualartgallery.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.virtualartgallery.entity.ArtWork;
import com.virtualartgallery.exception.ArtWorkNotFoundException;
import com.virtualartgallery.exception.FavArtWorkNotFoundException;
import com.virtualartgallery.exception.UserNotFoundException;
import com.virtualartgallery.util.DBConnection;

public class ArtWorkDAOImpl implements IArtWorkDAO {

	private static Connection connection;
	@Override
	public int addArtWork(ArtWork artwork) throws SQLException,ClassNotFoundException,IllegalArgumentException {
		connection = DBConnection.getConnection();
		int count = 0;
		
		String queryAdd = "INSERT INTO Artwork (ArtworkID,Title,Description,CreationDate,Medium,ImageURL) VALUES (?, ?, ?, ?, ?, ?)";
        
        PreparedStatement pstn = connection.prepareStatement(queryAdd);
        
        pstn.setInt(1, artwork.getArtworkId());
        pstn.setString(2, artwork.getTitle());
        pstn.setString(3, artwork.getDesc());
        String dob = artwork.getCreationDate();
        Date sqlDate = java.sql.Date.valueOf(dob);
        pstn.setDate(4, sqlDate);
        pstn.setString(5, artwork.getMedium());
        pstn.setString(6, artwork.getImageURL());

            
        count = pstn.executeUpdate();
        
        if(count == 0) {
        	throw new SQLException("Error in your SQL");
        }
        
        connection.close();
                
		return count;
	}

	@Override
	public int updateArtWork(ArtWork artwork) throws ArtWorkNotFoundException, SQLException, ClassNotFoundException,IllegalArgumentException {
		
		connection = DBConnection.getConnection();
		
		String queryfind = "SELECT * FROM artwork WHERE artworkid=?";
		
		String UpdateArtWorkQuery = "Update Artwork set Title=?,Description=?,CreationDate=?,Medium=?,ImageURL=? Where ArtworkID=?";
		
		PreparedStatement prepfind = connection.prepareStatement(queryfind);
		
		PreparedStatement pstn = connection.prepareStatement(UpdateArtWorkQuery);
		
		prepfind.setInt(1, artwork.getArtworkId());
		
		
		pstn.setString(1,artwork.getTitle());
		pstn.setString(2,artwork.getDesc());
		
		String dob = artwork.getCreationDate();
		Date sqlDate =Date.valueOf(dob);
		pstn.setDate(3, sqlDate);
		
		pstn.setString(4,artwork.getMedium());
		pstn.setString(5,artwork.getImageURL());
		pstn.setInt(6, artwork.getArtworkId());
		
		ResultSet rs = prepfind.executeQuery();
		
		int check = 0;
		while(rs.next()) {
			check = pstn.executeUpdate();
			
		}
		if(check==0) {
			throw new ArtWorkNotFoundException("ArtWork Not Found");
		}
		
		connection.close();
		return check;
	
	}

	@Override
	public int removeArtWork(int artworkId) throws ArtWorkNotFoundException, SQLException, ClassNotFoundException {
		
		connection = DBConnection.getConnection();
		
		String queryfind = "SELECT * FROM artwork WHERE artworkid=?";
		
		String removeArtwork = "DELETE FROM Artwork WHERE ArtworkID=?";
		
		PreparedStatement prepfind = connection.prepareStatement(queryfind);
		
		PreparedStatement pstn = connection.prepareStatement(removeArtwork);
		
		prepfind.setInt(1, artworkId);
		
		pstn.setInt(1,artworkId);
		
		ResultSet rs = prepfind.executeQuery();
	    int check = 0;
		while(rs.next()) {
			check = pstn.executeUpdate();
		}
		if(check==0) {
			throw new ArtWorkNotFoundException("ArtWork Not Found");
		}
		
		connection.close();
		return check;

		
	}

	@Override
	public ArtWork getArtWorkById(int artWorkId) throws ArtWorkNotFoundException, SQLException, ClassNotFoundException {
		
		connection = DBConnection.getConnection();
		
		ArtWork artwork = null;
		
		
		int artworkid = 0;
		String title = null;
		String description = null;
		Date creationDate = null;
		String medium = null;
		String imageUrl = null;
		
		
		
		
	    String query = "SELECT * FROM Artwork WHERE ArtworkID=?";
	    
	    PreparedStatement pstn = connection.prepareStatement(query);
	    		
	    pstn.setInt(1, artWorkId);
	    ResultSet resultSet = pstn.executeQuery();
	    
	    while(resultSet.next()) {

	       artworkid = resultSet.getInt("ArtworkID");
	       title =  resultSet.getString("Title");
	       description =  resultSet.getString("Description");
	       creationDate =  resultSet.getDate("CreationDate");
	       medium =  resultSet.getString("Medium");
	       imageUrl =  resultSet.getString("ImageURL");
	       
	       DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	       String strCreationDate = dateFormat.format(creationDate);
	       
	       artwork =  new ArtWork(artworkid,title,description,strCreationDate,medium,imageUrl);
	    }
	    
	    if (artwork == null) {
	    	throw new ArtWorkNotFoundException("Art Not Found");
	    }
	    
		return artwork;
	}

	@Override
	public List<ArtWork> searchArtworks(String keyword) throws ArtWorkNotFoundException, SQLException, ClassNotFoundException {
		
		connection = DBConnection.getConnection();
		
		ArtWork artwork = null;
		
		int artworkid = 0;
		String title = null;
		String description = null;
		Date creationDate = null;
		String medium = null;
		String imageUrl = null;
		
		List<ArtWork> artworks = new ArrayList<>();
	    String query = "SELECT * FROM Artwork WHERE Title LIKE ? OR Description LIKE ? OR Medium LIKE ?";
	    
	    PreparedStatement pstn = connection.prepareStatement(query) ;
	    String searchKeyword = "%" + keyword + "%";
	    pstn.setString(1, searchKeyword);
	    pstn.setString(2, searchKeyword);
	    pstn.setString(3, searchKeyword);
	    ResultSet resultSet = pstn.executeQuery();

	    while (resultSet.next()) {
	    	
	    	artworkid = resultSet.getInt("ArtworkID");
		    title =  resultSet.getString("Title");
		    description =  resultSet.getString("Description");
		    creationDate =  resultSet.getDate("CreationDate");
		    medium =  resultSet.getString("Medium");
		    imageUrl =  resultSet.getString("ImageURL");
		       
		    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		    String strCreationDate = dateFormat.format(creationDate);
		       
		    artwork =  new ArtWork(artworkid,title,description,strCreationDate,medium,imageUrl);
		    
		    artworks.add(artwork);
	     }
	    
	    if (artwork==null) {
	    	throw new ArtWorkNotFoundException("ArtWork Not Found");
	    }
	    
	    connection.close();
	    
	    return artworks;

	}
	
	@Override
	public List<ArtWork> viewArtworks() throws ArtWorkNotFoundException, SQLException, ClassNotFoundException {
		
		connection = DBConnection.getConnection();
		
		ArtWork artwork = null;
		
		int artworkid = 0;
		String title = null;
		String description = null;
		Date creationDate = null;
		String medium = null;
		String imageUrl = null;
		
		List<ArtWork> artworks = new ArrayList<>();
	    String query = "SELECT * FROM Artwork ";
	    
	    PreparedStatement pstn = connection.prepareStatement(query) ;

	    ResultSet resultSet = pstn.executeQuery();

	    while (resultSet.next()) {
	    	
	    	artworkid = resultSet.getInt("ArtworkID");
		    title =  resultSet.getString("Title");
		    description =  resultSet.getString("Description");
		    creationDate =  resultSet.getDate("CreationDate");
		    medium =  resultSet.getString("Medium");
		    imageUrl =  resultSet.getString("ImageURL");
		       
		    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		    String strCreationDate = dateFormat.format(creationDate);
		       
		    artwork =  new ArtWork(artworkid,title,description,strCreationDate,medium,imageUrl);
		    
		    artworks.add(artwork);
	     }
	    
	    if (artwork==null) {
	    	throw new ArtWorkNotFoundException("ArtWork Not Found");
	    }
	    
	    connection.close();
	    
	    return artworks;

	}

	
	
	}

