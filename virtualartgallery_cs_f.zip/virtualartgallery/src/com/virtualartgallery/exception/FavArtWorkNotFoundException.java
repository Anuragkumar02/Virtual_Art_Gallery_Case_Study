package com.virtualartgallery.exception;

public class FavArtWorkNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	public FavArtWorkNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	public FavArtWorkNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
