package com.virtualartgallery.exception;

public class GalleryNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	public GalleryNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	public GalleryNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
