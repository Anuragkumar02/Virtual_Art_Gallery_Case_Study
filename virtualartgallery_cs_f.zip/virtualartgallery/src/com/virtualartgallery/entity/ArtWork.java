package com.virtualartgallery.entity;

import java.sql.Date;
import java.sql.ResultSet;
import java.util.Objects;

public class ArtWork {
	
	private int artworkId;
	private String title;
	private String desc;
	private String creationDate;
	private String medium;
	private String imageURL;
	
	public ArtWork() {
		
	}
	
	
	public ArtWork( String title, String desc, String date, String medium, String imageURL) {
		this.title = title;
		this.desc = desc;
		this.creationDate = date;
		this.medium = medium;
		this.imageURL = imageURL;
	}
	
	public ArtWork(int artworkId, String title, String desc, String creationDate, String medium, String imageURL) {
		super();
		this.artworkId = artworkId;
		this.title = title;
		this.desc = desc;
		this.creationDate = creationDate;
		this.medium = medium;
		this.imageURL = imageURL;
	}

	public ArtWork(ResultSet resultSet) {
		// TODO Auto-generated constructor stub
	}

	public int getArtworkId() {
		return artworkId;
	}
	
	public void setArtworkId(int artworkId) {
		this.artworkId = artworkId;
	}


	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	public String getMedium() {
		return medium;
	}
	public void setMedium(String medium) {
		this.medium = medium;
	}
	public String getImageURL() {
		return imageURL;
	}
	public void setImageURL(String imageURL) {
		this.imageURL = imageURL;
	}
	
	
	@Override
	public int hashCode() {
		return Objects.hash(artworkId, creationDate, desc, imageURL, medium, title);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ArtWork other = (ArtWork) obj;
		return artworkId == other.artworkId && Objects.equals(creationDate, other.creationDate)
				&& Objects.equals(desc, other.desc) && Objects.equals(imageURL, other.imageURL)
				&& Objects.equals(medium, other.medium) && Objects.equals(title, other.title);
	}

	@Override
	public String toString() {
		return "ArtWork [artworkId=" + artworkId + ", title=" + title + ", desc=" + desc + ", creationDate="
				+ creationDate + ", medium=" + medium + ", imageURL=" + imageURL + "]";

}

}
