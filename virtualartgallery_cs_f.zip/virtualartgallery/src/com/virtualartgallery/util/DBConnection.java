package com.virtualartgallery.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	
	public static Connection connection;
	
	public static Connection getConnection() throws SQLException,ClassNotFoundException {
		 
		String connectionString =  PropertyUtil.getPropertyString();
		
		connection = DriverManager.getConnection(connectionString);
		return connection;
	}
	
	public static void closeConnection() throws SQLException {
		connection.close();
	}
	
	
}


